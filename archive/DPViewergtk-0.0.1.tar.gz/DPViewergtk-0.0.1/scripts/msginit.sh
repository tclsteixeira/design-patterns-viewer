#!/bin/bash

# It contains every localized text. We use it to create files containing other language versions.

msginit --input=../locale/DPViewergtk.pot --locale=pt --output-file=../locale/pt/DPViewergtk.po